<?php 
$sitemap->addItem("/", "1.0", "daily", "Today");
$sitemap->addItem("/panel", "0.9", "daily", "Today");
$sitemap->addItem("/hosting", "0.9", "daily", "Today");
$sitemap->addItem("/about", "0.9", "daily", "Today");
$sitemap->addItem("/contact", "0.9", "weekly", "Today");
$sitemap->addItem("/panel", "0.8", "monthly", "Today");
?>