<!-- JQUERY -->
  <script src="../node_modules/jquery/dist/jquery.min.js"></script>
  
  <link rel="shortcut icon" href="../resourses/img/logo_hestia/vector/default.svg" type="image/x-icon">
  <!-- Bootstrap -->
  <link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
  <!-- hestia -->
  <link rel="stylesheet" href="../resourses/scss/home_page.min.css">
  <!-- Fontawesome -->
  <link rel="stylesheet" href="../node_modules/@fortawesome/fontawesome-free/css/all.min.css" defer>
  <!-- SweetAlert2 -->
  <script src="../node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
  <!-- RichText -->
  <link rel="stylesheet" href="../node_modules/richtext_for_npm/src/richtext.min.css">
  <script src="../node_modules/richtext_for_npm/src/jquery.richtext.min.js"></script>
  <!-- Video.js base CSS -->
  <link href="../resourses/css/video-js.min.css" rel="stylesheet">