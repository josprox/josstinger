<li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa-solid fa-house-user"></i> Josstinger</a>
          <div class="dropdown-menu" aria-labelledby="dropdownId">
            <a class="dropdown-item" href="hestia"><i class="fa-solid fa-plus"></i> Agregar DNS</a>
            <a class="dropdown-item" href="productos"><i class="fa-solid fa-cart-plus"></i> Gestionar productos</a>
            <a class="dropdown-item" href="suscripciones"><i class="fa-solid fa-users"></i> Gestionar suscripciones</a>
            <a class="dropdown-item" href="catalogo"><i class="fa-regular fa-file"></i> Catálogo para facebook</a>
          </div>
        </li>