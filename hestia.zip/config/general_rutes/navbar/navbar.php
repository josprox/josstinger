<?php
// Aquí va el navbar_users
if(file_exists(__DIR__ . "/../../../routes/navbar/navbar.php")){
    include (__DIR__ . "/../../../routes/navbar/navbar.php");
}
?>