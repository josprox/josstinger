<?php
// Aquí va el footer_users plubic
?>
<!-- Cookies aviso -->
<script src="./../../resourses/js/aviso-cookies.js"></script>
<?php
if(file_exists(__DIR__ . "/../../../routes/footer/footer_users.php")){
    include (__DIR__ . "/../../../routes/footer/footer_users.php");
}
?>